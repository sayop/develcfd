mkdir build
cd ./build
ccmake ../../utilities/PreProcessor
make
cp pre.x ../
cd ../

